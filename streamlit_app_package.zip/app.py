import streamlit as st
import joblib
import numpy as np

# تحميل النموذج والسكالر
model = joblib.load("knn_model.pkl")
scaler = joblib.load("scaler_knn.pkl")

st.set_page_config(page_title="توقع نوع المنتج", layout="centered")
st.title("📱💻 توقع نوع الجهاز (جوال / لابتوب)")
st.markdown("أدخل الخصائص أدناه وسيقوم النموذج بتحديد ما إذا كان المنتج جوال أو لابتوب.")

# مدخلات المستخدم
brand = st.slider("🔷 ماركة الجهاز (رقم مشفر)", 0, 15, 0)
price = st.number_input("💰 السعر", min_value=1000, max_value=200000, value=5000)
quantity = st.slider("📦 الكمية المباعة", 1, 10, 1)
region = st.slider("📍 المنطقة (رقم مشفر)", 0, 5, 0)
days = st.slider("⏳ عدد أيام التخزين", 0, 100, 10)
ram = st.selectbox("💾 حجم الرام (GB)", [4, 6, 8, 12, 16])
rom = st.selectbox("💽 حجم التخزين (ROM)", [64, 128, 256, 512, 1024])
price_per_gb = price / ram
core_spec = st.slider("🧠 Core Specification (رقم مشفر)", 0, 10, 0)

if st.button("🔮 تنبؤ"):
    input_data = np.array([[brand, price, quantity, region, days, ram, rom, price_per_gb, core_spec]])
    input_scaled = scaler.transform(input_data)
    prediction = model.predict(input_scaled)[0]
    result = "📱 **جوال (Mobile Phone)**" if prediction == 1 else "💻 **لابتوب (Laptop)**"
    st.success(f"النتيجة: {result}")